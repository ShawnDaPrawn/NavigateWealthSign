import React from "react";

const Loader = () => {
  return (
    <div className="op-loading op-loading-infinity w-[4rem] text-neutral"></div>
  );
};

export default Loader;
